USE [master]
GO
/****** Object:  Database [Gan]    Script Date: 27/11/2018 08:13:55 ******/
CREATE DATABASE [Gan]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Gan_Data', FILENAME = N'C:\Gan_Data.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'Gan_Log', FILENAME = N'C:\Gan_Log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 1024KB )
GO
ALTER DATABASE [Gan] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Gan].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Gan] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Gan] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Gan] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Gan] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Gan] SET ARITHABORT OFF 
GO
ALTER DATABASE [Gan] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [Gan] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Gan] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Gan] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Gan] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Gan] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Gan] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Gan] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Gan] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Gan] SET  ENABLE_BROKER 
GO
ALTER DATABASE [Gan] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Gan] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Gan] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Gan] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Gan] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Gan] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Gan] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Gan] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Gan] SET  MULTI_USER 
GO
ALTER DATABASE [Gan] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Gan] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Gan] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Gan] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Gan] SET QUERY_STORE = OFF
GO
USE [Gan]
GO
/****** Object:  Table [dbo].[tblAttendence]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblAttendence](
	[Recno] [int] NULL,
	[ChildID] [int] NULL,
	[ChildFirstName] [nvarchar](50) NULL,
	[ChildLastName] [nvarchar](50) NULL,
	[Date] [date] NULL,
	[Attend] [bit] NULL,
	[Stays] [bit] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblChildren]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblChildren](
	[childID] [int] IDENTITY(1,1) NOT NULL,
	[ChildFirstName] [nvarchar](50) NULL,
	[ChildLastName] [nvarchar](50) NULL,
	[ChildSex] [nvarchar](50) NULL,
	[ChildAddress] [nvarchar](200) NULL,
	[ChildBirthDay] [datetime] NULL,
	[ChildRegDate] [datetime] NULL,
	[ChildIDCard] [nvarchar](50) NULL,
	[ChildCity] [nvarchar](50) NULL,
	[ChildRemarks] [nvarchar](100) NULL,
	[IdParent] [int] NULL,
 CONSTRAINT [PK_tblChildren] PRIMARY KEY CLUSTERED 
(
	[childID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblParents]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblParents](
	[IdParent] [int] IDENTITY(1,1) NOT NULL,
	[FatherName] [nvarchar](50) NULL,
	[MotherName] [nvarchar](50) NULL,
	[FatherPhone] [nvarchar](50) NULL,
	[MotherPhone] [nvarchar](50) NULL,
	[childID] [int] NULL,
	[childFirstName] [nvarchar](50) NULL,
	[childLastName] [nvarchar](50) NULL,
	[Email] [nvarchar](50) NULL,
	[Attachment] [nvarchar](150) NULL,
 CONSTRAINT [PK_tblParents] PRIMARY KEY CLUSTERED 
(
	[IdParent] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblStaff]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblStaff](
	[StaffID] [int] IDENTITY(1,1) NOT NULL,
	[StaffFirstName] [nvarchar](50) NULL,
	[StaffLastName] [nvarchar](50) NULL,
	[StaffAge] [nvarchar](50) NULL,
	[StaffPosition] [nvarchar](50) NULL,
	[StaffWorkStart] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblUsers]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblUsers](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[UserMail] [nvarchar](50) NULL,
	[UserType] [nvarchar](50) NULL,
	[UserPerms] [nvarchar](50) NULL,
	[UserFirstName] [nvarchar](50) NULL,
	[UserLastName] [nvarchar](50) NULL,
	[UserAddress] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblWorkHours]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblWorkHours](
	[RecNo] [int] NULL,
	[Date] [date] NULL,
	[StaffID] [int] NOT NULL,
	[StaffFirstName] [nvarchar](50) NULL,
	[StaffLastName] [nvarchar](50) NULL,
	[WorkHours] [int] NULL
) ON [PRIMARY]
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-07-19' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-07-19' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-07-19' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-07-19' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-07-19' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-07-19' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-07-19' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-07-19' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-07-20' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-07-20' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-07-20' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-07-20' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-07-20' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-07-20' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-07-20' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-07-20' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-07-23' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-07-23' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-07-23' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-07-23' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-07-23' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-07-23' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-07-23' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-07-23' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-09-04' AS Date), 1, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-09-04' AS Date), 1, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-09-04' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-09-04' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-09-04' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-09-04' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-09-04' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-09-04' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-09-03' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-09-03' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-09-03' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-09-03' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-09-03' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-09-03' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-09-03' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-09-03' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-07-22' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-07-22' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-07-22' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-07-22' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-07-22' AS Date), 1, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-07-22' AS Date), 1, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-07-22' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-07-22' AS Date), 1, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 2, N'����', N'���', CAST(N'2018-07-21' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 3, N'�����', N'����', CAST(N'2018-07-21' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 4, N'����', N'�� ����', CAST(N'2018-07-21' AS Date), 1, 1)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 7, N'����', N'���', CAST(N'2018-07-21' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 8, N'���', N'�����', CAST(N'2018-07-21' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 9, N'����', N'���', CAST(N'2018-07-21' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 11, N'����', N'���', CAST(N'2018-07-21' AS Date), 0, 0)
GO
INSERT [dbo].[tblAttendence] ([Recno], [ChildID], [ChildFirstName], [ChildLastName], [Date], [Attend], [Stays]) VALUES (NULL, 12, N'����', N'���', CAST(N'2018-07-21' AS Date), 0, 0)
GO
SET IDENTITY_INSERT [dbo].[tblChildren] ON 
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (2, N'����', N'���', N'���', N'������ 14', CAST(N'1988-05-01T00:00:00.000' AS DateTime), CAST(N'2018-01-06T00:00:00.000' AS DateTime), N'314397241', N'�����', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (3, N'�����', N'����', N'����', N'������ 14', CAST(N'1992-09-15T00:00:00.000' AS DateTime), CAST(N'2017-01-01T00:00:00.000' AS DateTime), N'203989074', N'�����', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (4, N'����', N'�� ����', N'����', N'����� 13', CAST(N'2006-01-15T00:00:00.000' AS DateTime), CAST(N'2018-06-13T00:00:00.000' AS DateTime), N'123456789', N'�������', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (7, N'����', N'���', N'����', N'������  146', CAST(N'1994-10-01T00:00:00.000' AS DateTime), CAST(N'2018-06-24T00:00:00.000' AS DateTime), N'314397254', N'�����', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (8, N'���', N'�����', N'����', N'��� 45', CAST(N'1996-04-01T00:00:00.000' AS DateTime), CAST(N'2018-06-24T00:00:00.000' AS DateTime), N'314397236', N'�����', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (9, N'����', N'���', N'����', N'��������� 24', CAST(N'1968-01-01T00:00:00.000' AS DateTime), CAST(N'2018-06-13T00:00:00.000' AS DateTime), N'123654998', N'�� ����', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (11, N'����', N'���', N'���', N'������ 235', CAST(N'2018-01-01T00:00:00.000' AS DateTime), CAST(N'2018-06-13T00:00:00.000' AS DateTime), N'123', N'�����', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (12, N'����', N'���', N'���', N'������ 14', CAST(N'2018-01-01T00:00:00.000' AS DateTime), CAST(N'2018-06-13T00:00:00.000' AS DateTime), N'314397524', N'314397524', NULL, NULL)
GO
INSERT [dbo].[tblChildren] ([childID], [ChildFirstName], [ChildLastName], [ChildSex], [ChildAddress], [ChildBirthDay], [ChildRegDate], [ChildIDCard], [ChildCity], [ChildRemarks], [IdParent]) VALUES (13, N'defee', N'', N'', N'', CAST(N'2018-01-01T00:00:00.000' AS DateTime), CAST(N'2018-11-02T00:00:00.000' AS DateTime), N'314397654', N'314397654', N'', 2)
GO
SET IDENTITY_INSERT [dbo].[tblChildren] OFF
GO
SET IDENTITY_INSERT [dbo].[tblParents] ON 
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (1, N'���� ���', N'������ ���', N'0522489194', N'0523145645', 2, N'����', N'���', N'addajimmy@gmail.com', N'C:\Users\User\Desktop\KaplanMenu.pdf')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (2, N'���� ���', N'������ ���', N'0522489194', N'0526458788', 2, N'����', N'���', N'addajimmy@gmail.com', N'')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (3, N'���� �����', N'����', N'052222222', N'052111111', 4, N'����', N'�����', N'addajimmy@gmail.com', NULL)
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (4, N'����', N'��', N'052111111', N'052333333', 5, N'��', N'���', N'yogev@crtv.co.il', NULL)
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (5, N'����', N'����', N'05505', N'0505550', 6, N'����', N'�����', N'jimmy@crtv.co.il', NULL)
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (6, N'����', N'����', N'0501650', N'0165156', 4, N'����', N'�� ����', N'addajimmy@gmail.com', NULL)
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (7, N'���� n', N'���� 1', N'0501650', N'0165156', 4, N'����', N'�� ����', N'', NULL)
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (8, N'���', N'���', N'0522489194', N'052222222', 4, N'����', N'�� ����', N'', N'C:\Users\User\Desktop\������ ����� �����.pdf!.pdf')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (9, N'����', N'���', N'0528774804', N'053-123456789', 8, N'�����', N'�����', N'hugoadda@gmail.com ', N'C:\Users\User\Desktop\������ ����� �����.pdf')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (11, N'����� ', N'����', N'052222222', N'0552222222', 8, N'�����', N'�����', N'Karinii_@walla.co.il ', N'C:\Users\User\Desktop\������ ����� �����.pdf')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (12, N'����', N'�����', N'0528774804', N'025874444', 2, N'���', N'���', N'addajimmy@gmail.com', N'c:\')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (13, N'���� �����', N'���� �����', N'0528774804', N'0528966354', 8, N'�����', N'�����', N'', N'c:\')
GO
INSERT [dbo].[tblParents] ([IdParent], [FatherName], [MotherName], [FatherPhone], [MotherPhone], [childID], [childFirstName], [childLastName], [Email], [Attachment]) VALUES (14, N'�����', N'�����', N'0123', N'0123456', 3, N'�����', N'�����', N'', N'c:\')
GO
SET IDENTITY_INSERT [dbo].[tblParents] OFF
GO
SET IDENTITY_INSERT [dbo].[tblStaff] ON 
GO
INSERT [dbo].[tblStaff] ([StaffID], [StaffFirstName], [StaffLastName], [StaffAge], [StaffPosition], [StaffWorkStart]) VALUES (1, N'������', N'���', N'56', N'����', CAST(N'2005-01-01T09:53:07.000' AS DateTime))
GO
INSERT [dbo].[tblStaff] ([StaffID], [StaffFirstName], [StaffLastName], [StaffAge], [StaffPosition], [StaffWorkStart]) VALUES (2, N'���', N'���', N'45', N'����', CAST(N'2015-01-01T09:53:07.000' AS DateTime))
GO
INSERT [dbo].[tblStaff] ([StaffID], [StaffFirstName], [StaffLastName], [StaffAge], [StaffPosition], [StaffWorkStart]) VALUES (3, N'���', N'���', N'25', N'�����', CAST(N'2018-04-01T15:57:05.000' AS DateTime))
GO
INSERT [dbo].[tblStaff] ([StaffID], [StaffFirstName], [StaffLastName], [StaffAge], [StaffPosition], [StaffWorkStart]) VALUES (5, N'�����', N'����', N'26', N'����', CAST(N'2018-07-01T23:16:38.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[tblStaff] OFF
GO
SET IDENTITY_INSERT [dbo].[tblUsers] ON 
GO
INSERT [dbo].[tblUsers] ([UserID], [UserName], [UserMail], [UserType], [UserPerms], [UserFirstName], [UserLastName], [UserAddress], [Password]) VALUES (1, N'admin', N'addajimy@gmail.com', N'admin', N'A', N'����', N'���', N'������ 14 , �����', N'server')
GO
INSERT [dbo].[tblUsers] ([UserID], [UserName], [UserMail], [UserType], [UserPerms], [UserFirstName], [UserLastName], [UserAddress], [Password]) VALUES (2, N'user', N'user@gmail.com', N'', N'', N'����', N'���', N'������ 14', N'user')
GO
INSERT [dbo].[tblUsers] ([UserID], [UserName], [UserMail], [UserType], [UserPerms], [UserFirstName], [UserLastName], [UserAddress], [Password]) VALUES (3, N'guest', N'guest@gmail.com', N'guest', N'G', N'�����', N'�����', N'�����', N'guest')
GO
INSERT [dbo].[tblUsers] ([UserID], [UserName], [UserMail], [UserType], [UserPerms], [UserFirstName], [UserLastName], [UserAddress], [Password]) VALUES (4, N'', N'', N'', N'', N'', N'', N'', N'')
GO
SET IDENTITY_INSERT [dbo].[tblUsers] OFF
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-22' AS Date), 1, N'������', N'���', 2)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-22' AS Date), 2, N'���', N'���', 4)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-23' AS Date), 1, N'������', N'���', 2)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-23' AS Date), 2, N'���', N'���', 4)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-23' AS Date), 3, N'���', N'���', 5)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-23' AS Date), 5, N'�����', N'����', 8)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-22' AS Date), 3, N'���', N'���', 5)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-22' AS Date), 5, N'�����', N'����', 8)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-21' AS Date), 1, N'������', N'���', 2)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-21' AS Date), 2, N'���', N'���', 2)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-21' AS Date), 3, N'���', N'���', 2)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-21' AS Date), 5, N'�����', N'����', 2)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-20' AS Date), 1, N'������', N'���', 4)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-20' AS Date), 2, N'���', N'���', 4)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-20' AS Date), 3, N'���', N'���', 4)
GO
INSERT [dbo].[tblWorkHours] ([RecNo], [Date], [StaffID], [StaffFirstName], [StaffLastName], [WorkHours]) VALUES (NULL, CAST(N'2018-07-20' AS Date), 5, N'�����', N'����', 4)
GO
/****** Object:  StoredProcedure [dbo].[AddAttendence]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Proc [dbo].[AddAttendence]
@ChildID int,
@ChildFirstName nvarchar(50),
@ChildLastName nvarchar(50),
@Date DateTime,
@Attend bit,
@Stays bit
as

insert into tblAttendence(ChildID,ChildFirstName,ChildLastName,Date,Attend,Stays)
values (@ChildID,@ChildFirstName,@ChildLastName,@Date,@Attend,@Stays)
GO
/****** Object:  StoredProcedure [dbo].[AddWorkHours]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create Proc [dbo].[AddWorkHours]
@StaffID int,
@StaffFirstName nvarchar(50),
@StaffLastName nvarchar(50),
@Date DateTime,
@WorkHours int
as
insert into tblWorkHours (StaffID,StaffFirstName,StaffLastName,Date,WorkHours)
values (@StaffID,@StaffFirstName,@StaffLastName,@Date,@WorkHours)
GO
/****** Object:  StoredProcedure [dbo].[ChildAdd]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Proc [dbo].[ChildAdd]
@ChildFirstName nvarchar(50),
@ChildLastName nvarchar(50), 
@ChildSex nnvarchar(50),
@ChildBirthDay datetime,
@ChildRegDate datetime,
@ChildAddress nvarchar(250),
@ChildIDCard nvarchar(50),
@ChildCity nvarchar(50),
@ChildRemarks nvarchar(100),
@IdParent int
as

insert into tblChildren (ChildFirstName,ChildLastName,ChildSex,ChildBirthDay,ChildRegDate,ChildAddress,ChildIDCard,ChildCity,ChildRemarks,IdParent)
values (@ChildFirstName,@ChildLastName,@ChildSex,@ChildBirthDay,@ChildRegDate,@ChildAddress,@ChildIDCard,@ChildCity,@ChildRemarks,@IdParent)
GO
/****** Object:  StoredProcedure [dbo].[ChildUpd]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc [dbo].[ChildUpd]
@ChildID int,
@ChildFirstName nvarchar(50),
@ChildLastName nvarchar(50), 
@ChildSex nvarchar(50),
@ChildBirthDay datetime,
@ChildAddress nvarchar(250),
@ChildIDCard nvarchar (50),
@ChildCity nvarchar(50),
@ChildRemarks nvarchar(100)
as
update tblChildren set ChildFirstName= @ChildFirstName,ChildLastName=@ChildLastName,ChildSex=@ChildSex,ChildBirthDay=@ChildBirthDay,ChildAddress=@ChildAddress,ChildIDCard=@ChildIDCard,ChildCity=@ChildCity,ChildRemarks=@ChildRemarks
where childID=@ChildID
GO
/****** Object:  StoredProcedure [dbo].[ParentAdd]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Proc [dbo].[ParentAdd]
@FatherName nvarchar(50),
@MotherName nvarchar(50), 
@FatherPhone nvarchar(50),
@MotherPhone nvarchar(50),
@childID int,
@childFirstName nvarchar(50),
@childLastName nvarchar(50),
@Email nvarchar(50),
@Attachment nvarchar(150)
as

insert into tblParents(FatherName,MotherName,FatherPhone,MotherPhone,childID,childFirstName,childLastName,Email,Attachment)
values (@FatherName,@MotherName,@FatherPhone,@MotherPhone,@childID,@childLastName,@childLastName,@Email,@Attachment)
GO
/****** Object:  StoredProcedure [dbo].[selecttblAttendence]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc [dbo].[selecttblAttendence]
@date date
as
Select Date,ChildFirstName,ChildLastName,Attend,Stays from tblAttendence where date=@date
GO
/****** Object:  StoredProcedure [dbo].[selectWorkHours]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc [dbo].[selectWorkHours]
@date date
as
Select Date,StaffFirstName,StaffLastName,WorkHours from tblWorkHours where date=@date
GO
/****** Object:  StoredProcedure [dbo].[StaffAdd]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create Proc [dbo].[StaffAdd]
@StaffFirstName nvarchar(50),
@StaffLastName nvarchar(50),
@StaffAge int, 
@StaffPosition nvarchar(50),
@StaffWorkStart DateTime
as

insert into tblStaff(StaffFirstName,StaffLastName,StaffAge,StaffPosition,StaffWorkStart)
values (@StaffFirstName,@StaffLastName,@StaffAge,@StaffPosition,@StaffWorkStart)
GO
/****** Object:  StoredProcedure [dbo].[UpdParent]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc [dbo].[UpdParent]
@IdParent int,
@FatherName nvarchar(50),
@MotherName nvarchar(50), 
@FatherPhone nvarchar(50),
@MotherPhone nvarchar(50),
@childID int,
@childFirstName nvarchar(50),
@childLastName nvarchar(50),
@Email nvarchar(50),
@Attachment nvarchar(150)
as
update tblParents set FatherName= @FatherName,MotherName=@MotherName,FatherPhone=@FatherPhone,MotherPhone=@MotherPhone,childID=@childID,childFirstName=@childFirstName,childLastName=@childLastName,Email=@Email,Attachment=@Attachment
where IdParent=@IdParent
GO
/****** Object:  StoredProcedure [dbo].[UserAddGan]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create proc [dbo].[UserAddGan]
@UserFirstName nvarchar(50),
@UserLastName  nvarchar(50),
@UserType nvarchar(50),
@UserAddress nvarchar(250),
@UserName  nvarchar(50),
@Password  nvarchar(50),
@UserMail nvarchar(100),
@UserPerms nvarchar(50)
As

insert into tblUsers(UserFirstName,UserLastName,UserType,UserAddress,UserName,Password,UserMail,UserPerms)
values (@UserFirstName,@UserLastName,@UserType,@UserAddress,@UserName,@Password,@UserMail,@UserPerms)
GO
/****** Object:  StoredProcedure [dbo].[WorkHoursRep]    Script Date: 27/11/2018 08:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Proc [dbo].[WorkHoursRep]
(
@fromdate date,
@Todate date
)
as

select StaffFirstName,StaffLastName,SUM (WorkHours) as worksum from tblWorkHours
where Date between @fromdate and @Todate
group by StaffID,StaffFirstName,StaffLastName
Order by StaffID asc
GO
USE [master]
GO
ALTER DATABASE [Gan] SET  READ_WRITE 
GO
